clear;

close all;

clc;

% Task 4 specifications

fs=1;

ws=2*pi;

L=20;

ts=1/fs;

n1=-L/2:-1;

n2=1:L/2;

for i = 1:size(n1,2)

 hdif1(i) = cos(n1(i).*pi)./(n1(i).*pi);

 hamming_win1(i) = 0.54+0.46*cos(2*pi.*n1(i)/L);

end

for i = 1:size(n2,2)

 hdif2(i) = cos(n2(i).*pi)./(n2(i).*pi);

 hamming_win2(i) = 0.54+0.46*cos(2*pi.*n2(i)/L);

end

% Plot of the spectrum for the digital differentiator

for i=1:2001

 w(i)=pi*fs*(i-1001)/1000;

 z=exp(1i*w(i)*ts);

 h_i(i)=1i*w(i)./ws ;

 hf(i)=z.^(-1*L/2).*(sum(hdif1.*z.^(-n1))+sum(hdif2.*z.^(-n2)));

 hm(i)=z.^(-1*L/2).*(sum(hdif1.*hamming_win1.*z.^(-n1))+sum(hdif2.*hamming_win2.*z.^(-n2)));

end

figure;

subplot(2,1,1);

plot(w/(2*pi),abs(h_i));

axis([-0.6 0.6 0 1]);

xlabel('frequency(Hz)');

ylabel('|H(w)|');

title('Magnitude Spectrum of Ideal case');

subplot(2,1,2);

plot(w/(2*pi),angle(h_i));

axis([-0.6 0.6 -2 4]);

xlabel('frequency(Hz)');

ylabel('Phase of H(w)');

title('Phase Spectrum of Ideal case');

figure;

subplot(2,1,1);

plot(w/(2*pi),abs(hf));


xlabel('frequency(Hz)');

ylabel('|H(w)|');

title('Magnitude Spectrum of Rectangular Window');

subplot(2,1,2);

plot(w/(2*pi),angle(hf));

xlabel('frequency(Hz)');

ylabel('Phase of H(w)');

title('Phase Spectrum of Rectangular Window');

figure;

subplot(2,1,1);

plot(w/(2*pi),abs(hm));

xlabel('frequency(Hz)');

ylabel('|H(w)|');

title('Magnitude Spectrum of Hamming Window');

subplot(2,1,2);

plot(w/(2*pi),angle(hm));

xlabel('frequency(Hz)');
ylabel('Phase of H(w)');
title('Phase Spectrum of Hamming Window');