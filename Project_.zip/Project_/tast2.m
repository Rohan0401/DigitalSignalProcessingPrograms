clear;
close all;
clc;
% Task 2 specifications
fs=2000;
fh=550;
fl=250;
L=109;
ts=1/fs;
n=-1*L/2:L/2;
for i = 1:size(n,2)
bandpass(i) = sinc(2*fh*ts.*n(i))*2*fh*ts-sinc(2*fl*ts.*n(i))*2*fl*ts;
blackman_win(i) = 0.42+0.5*cos(2*pi.*n(i)/L)+0.08*cos(4*pi.*n(i)/L);
hn(i) = bandpass(i) * blackman_win(i);
end
% Plot for the spectrum of the bandpass filter
for i=1:1000
w(i)=pi*fs*i/1000;
z=exp(1i*w(i)*ts);
hf(i)=z^(-1*L/2)*sum(hn.*z.^(-n));
end
figure;
plot(w/(2*pi),abs(hf));
xlabel('frequency (Hz)');
ylabel('|H(w)|');
title('Magnitude Spectrum');
figure;
plot(w/(2*pi),angle(hf));
xlabel('frequency (Hz)');
ylabel('|H(w)|');
title('Magnitude Spectrum');